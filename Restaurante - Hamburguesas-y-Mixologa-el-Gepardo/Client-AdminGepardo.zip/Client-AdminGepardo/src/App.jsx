import { useEffect } from "react";
import { Toaster } from "react-hot-toast";
import { AppRoutes } from "./app/routes/AppRoutes";
import { useAuthStore } from "./features/auth/store/authStore";
import "./App.css";

function App() {
  const checkAuth = useAuthStore((state) => state.checkAuth);
  const isCheckingAuth = useAuthStore((state) => state.isCheckingAuth);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  if (isCheckingAuth) return null;

  return (
    <>
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            fontFamily: "inherit",
            fontWeight: "600",
            fontSize: "1rem",
            borderRadius: "8px",
          },
        }}
      />
      <AppRoutes />
    </>
  );
}

export default App;